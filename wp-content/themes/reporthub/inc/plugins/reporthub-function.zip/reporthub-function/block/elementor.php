<?php

/**
 * @author  Themelazer
 * @since   1.0
 * @version 1.0
 * @package reporthub-function
 */

if ( ! defined( 'ABSPATH' ) ) exit;
  if(defined('ELEMENTOR_VERSION')):
  class reporthub_Shortcode{	
      public static $_instance;
      public $localize_data = array();
    	public function __construct(){
      		    add_action( 'elementor/init', array($this, 'reporthub_elementor_init'));
              add_action( 'elementor/widgets/register', array($this, 'reporthub_shortcode_elements'));
              add_action( 'elementor/editor/after_enqueue_styles', array( $this, 'editor_enqueue_styles' ) );
              add_action( 'elementor/frontend/before_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
              add_action( 'elementor/preview/enqueue_styles', array( $this, 'preview_enqueue_scripts' ) );     
    	} 
      public function enqueue_scripts() {}
      public function editor_enqueue_styles() {}
      public function preview_enqueue_scripts() {}
      public function reporthub_elementor_init(){\Elementor\Plugin::$instance->elements_manager->add_category(
            'reporthub-elements',
            [
                'title' =>esc_html__( 'reporthub Elements', 'reporthub' ),
                'icon' => 'fa fa-plug',
            ],
            1
          );
      }
      public function reporthub_shortcode_elements($widgets_manager){ 
            require_once 'slider.php';
            $widgets_manager->register(new Elementor\reporthub_slider());
            require_once 'slider-center.php';
            $widgets_manager->register(new Elementor\reporthub_slider_center());  
            require_once 'grid-post.php';
            $widgets_manager->register(new Elementor\reporthub_grid_post());
            require_once 'list-post.php';
            $widgets_manager->register(new Elementor\reporthub_list_post());
            require_once 'large-list-post.php';
            $widgets_manager->register(new Elementor\reporthub_large_list_post());
            require_once 'small-list-post.php';
            $widgets_manager->register(new Elementor\reporthub_small_list());
            require_once 'carousel.php';
            $widgets_manager->register(new Elementor\reporthub_carousel());
            require_once 'carousel-z.php';
            $widgets_manager->register(new Elementor\reporthub_carousel_z());
            require_once 'link-list-post.php';
            $widgets_manager->register(new Elementor\reporthub_link_list_post());
            require_once 'feature-link-list.php';
            $widgets_manager->register(new Elementor\reporthub_feature_link_list_post());
            require_once 'feature-link-marquee.php';
            $widgets_manager->register(new Elementor\reporthub_feature_link_marquee_post());
            require_once 'feature-link-marquee-category.php';
            $widgets_manager->register(new Elementor\reporthub_feature_link_marquee_category());
            require_once 'promo-box.php';
            $widgets_manager->register(new Elementor\reporthub_promo_box());
            require_once 'large_grid.php';
            $widgets_manager->register(new Elementor\reporthub_large_grid_post());  
            require_once 'feature_list.php';
            $widgets_manager->register(new Elementor\reporthub_feature_list());
            require_once 'feature-slider.php';
            $widgets_manager->register(new Elementor\reporthub_feature_slider());
            require_once 'feature_list_z.php';
            $widgets_manager->register(new Elementor\reporthub_feature_list_z());
            require_once 'feature-card-post.php';
            $widgets_manager->register(new Elementor\reporthub_feature_card_post());
      }
    	public static function reporthub_get_instance() {
            if (!isset(self::$_instance)) {
                self::$_instance = new reporthub_Shortcode();
            }
            return self::$_instance;
      }
  }
  $reporthub_Shortcode = reporthub_Shortcode::reporthub_get_instance();
endif;