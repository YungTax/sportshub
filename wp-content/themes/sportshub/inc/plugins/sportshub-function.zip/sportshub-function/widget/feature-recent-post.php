<?php

/**
 * @author  Themelazer
 * @since   1.0
 * @version 1.0
 * @package sportshub-function
 */

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit;

class sportshub_feature_recent_post extends Widget_Base {

  public $base;

    public function get_name() {
        return 'sportshub-feature-recent-post';
    }

    public function get_title() {
        return esc_html__( 'Feature Recent Post', 'sportshub' );
    }

    public function get_icon() { 
        return 'eicon-post-list';
    }

    public function get_categories() {
       return [ 'sportshub-elements' ];
    }

  protected function _register_controls() {

        $this->start_controls_section(
            'section_tab',
            [
                'label' => esc_html__('Post Query And Setting', 'sportshub'),
            ]
        );

        $this->add_control(
        'section_title', [
        'label'       => esc_html__( 'Section Title', 'sportshub' ),
        'type'        =>Controls_Manager::TEXT,
        'label_block'   => true,
        'placeholder'    => esc_html__( 'Section text', 'sportshub' )        
        ]
        );
        
        $this->add_control(
            'post_grid_layout',
            [
                'label'     =>esc_html__( 'Grid post Layout', 'sportshub' ),
                'description' =>esc_html__( 'Select Post Layout per page.', 'sportshub'),
                'type'      =>Controls_Manager::SELECT,
                'default'   => 'grid_layout1',
                'options'   => [
                        'grid_layout1'    =>esc_html__( 'Grid Layout 1', 'sportshub' ),
                        'grid_layout2'    =>esc_html__( 'Grid Layout 2', 'sportshub' ),
                       
                    ],
            ]
        );

        $this->add_control(
            'post_grid_col',
            [
                'label'     =>esc_html__( 'Grid post Columns', 'sportshub' ),
                'description' => esc_html__( 'Select Post Columns per page.', 'sportshub'),
                'type'      =>Controls_Manager::SELECT,
                'default'   => 'grid_col4',
                'options'   => [
                        'grid_col1'    =>esc_html__( 'Grid 1 Columns', 'sportshub' ),
                        'grid_col2'    =>esc_html__( 'Grid 2 Columns', 'sportshub' ),
                        'grid_col3'    =>esc_html__( 'Grid 3 Columns', 'sportshub' ),
                        'grid_col4'    =>esc_html__( 'Grid 4 Columns', 'sportshub' ),
                        'grid_col5'    =>esc_html__( 'Grid 5 Columns', 'sportshub' ),
                    ],
            ]
        );
       

        
        $this->add_control(
          'post_count',
          [
            'label'         => esc_html__( 'Post count', 'sportshub' ),
            'description'   => esc_html__( 'Select number of posts per page (total posts to show).', 'sportshub'),
            'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 1,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'size' => 4,
                ],   
          ]
        );


        $this->add_control(
            'post_cats',
            [
                'label' =>esc_html__('Select Categories', 'sportshub'),
                'description' => esc_html__('Select category filter for this block.', 'sportshub' ),
                'type'      =>Controls_Manager::SELECT2,
                 'options'   => $this->post_category(),
                'label_block' => true,
                'multiple'  => true,
            ]
        ); 
        $this->add_control(
            'thumbnail_size',
            [
                'label'     =>esc_html__( 'Post Thumbnail size', 'sportshub' ),
                'description'=>esc_html__( 'Select Thumbnail size for this block'),
                'type'      => Controls_Manager::SELECT,
                'default'   => 'sportshub_large_feature',
                'options'   => [
                        'sportshub_slider_grid_small'  =>esc_html__( 'sportshub Slider Small Grid', 'sportshub' ),
                        'sportshub_justify_feature'    =>esc_html__( 'sportshub Justify Feature', 'sportshub' ),
                        'sportshub_small_feature'      =>esc_html__( 'sportshub Small Feature', 'sportshub' ),
                        'sportshub_large_feature'      =>esc_html__( 'sportshub Large Feature','sportshub'),
                        'sportshub_large_slider_image' =>esc_html__( 'sportshub Large Slider', 'sportshub'),
                        'sportshub_slider_grid_large'  =>esc_html__( 'sportshub Slider Grid Large', 'sportshub'),
                        'sportshub_list_post_large'    =>esc_html__( 'sportshub Large Post List',  'sportshub'),
                        'sportshub_carousel'           =>esc_html__( 'sportshub Carousel', 'sportshub'),
                        'sportshub_marsonry'           =>esc_html__( 'sportshub Masonry', 'sportshub'),
                    ],
            ]
        );        
        $this->add_control(
            'post_title_html_tag',
            [
                'label'     =>esc_html__( 'Post Title Html Tag', 'sportshub' ),
                'description'=>esc_html__( 'Select Html title tag for this block '),
                'type' => Controls_Manager::CHOOSE,
                'label_block' => true,
                'toggle' => false,
                'default' => 'h4',
                'options' => array(
                    'h1' => [
                        'title' => esc_html__('H1', 'sportshub'),
                        'icon' => 'eicon-editor-h1'
                    ],
                    'h2' => [
                        'title' => esc_html__('H2', 'sportshub'),
                        'icon' => 'eicon-editor-h2'
                    ],
                    'h3' => [
                        'title' => esc_html__('H3', 'sportshub'),
                        'icon' => 'eicon-editor-h3'
                    ],
                    'h4' => [
                        'title' => esc_html__('H4', 'sportshub'),
                        'icon' => 'eicon-editor-h4'
                    ],
                    'h5' => [
                        'title' => esc_html__('H5', 'sportshub'),
                        'icon' => 'eicon-editor-h5'
                    ],
                    'h6' => [
                        'title' => esc_html__('H6', 'sportshub'),
                        'icon' => 'eicon-editor-h6'
                    ],
                    'div' => [
                        'title' => esc_html__('div', 'sportshub'),
                        'icon' => 'eicon-font'
                    ]

                ),
               
                
            ]
        );
        $this->add_control(
            'blog_text_align',
            [
                'label'     =>esc_html__( 'Alignment', 'sportshub' ),
                'type'      => Controls_Manager::CHOOSE,
                'label_block' => true,
                'toggle' => false,
                'default' => 'center',
                'options'   => array(
                       'left' => [
                        'title' => esc_html__('Text Align Left', 'sportshub'),
                        'icon' => 'eicon-text-align-left'
                       ],
                       'center' => [
                        'title' => esc_html__('Text Align Center', 'sportshub'),
                        'icon' => 'eicon-text-align-center'
                       ],
                       'right' => [
                        'title' => esc_html__('Text Align right', 'sportshub'),
                        'icon' => 'eicon-text-align-right'
                       ],
                ),
            ]
        );
        $this->add_control(
              'background_color', [
              'condition' => [ 'post_grid_layout' => 'grid_layout2' ],
              'label'    => esc_html__( 'Background color', 'sportshub' ),        
              'default'  => '#FFF',
              'type'     => Controls_Manager::COLOR,
              'selectors'  => [
               '{{WRAPPER}} .blog-style-one .text-box.themelazer_card' => 'background: {{VALUE}};',
              ],
            ]
        );
        $this->add_control(
            'show_thumbnail',
            [
                'label' => esc_html__('Show Thumbnail', 'sportshub'),
                'type' =>Controls_Manager::SWITCHER,
                'label_on' => esc_html__('yes', 'sportshub'),
                'label_off' => esc_html__('no', 'sportshub'),
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'show_cat',
            [
                'label' => esc_html__('Show Category', 'sportshub'),
                'type' =>Controls_Manager::SWITCHER,
                'label_on' => esc_html__('yes', 'sportshub'),
                'label_off' => esc_html__('no', 'sportshub'),
                'default' => 'no',
            ]
        );
        $this->add_control(
            'show_meta',
            [
                'label' => esc_html__('Show Meta', 'sportshub'),
                'type' =>Controls_Manager::SWITCHER,
                'label_on' => esc_html__('yes', 'sportshub'),
                'label_off' => esc_html__('no', 'sportshub'),
                'default' => 'yes',
            ]
        );
        $this->add_control(
            'show_author',
            [
                'label' => esc_html__('Show Author', 'sportshub'),
                'type' =>Controls_Manager::SWITCHER,
                'label_on' => esc_html__('yes', 'sportshub'),
                'label_off' => esc_html__('no', 'sportshub'),
                'default' => 'no',
            ]
        );
        $this->add_control(
            'show_date',
            [
                'label' => esc_html__('Show Date', 'sportshub'),
                'type' =>Controls_Manager::SWITCHER,
                'label_on' => esc_html__('yes', 'sportshub'),
                'label_off' => esc_html__('no', 'sportshub'),
                'default' => 'yes',
            ]
        );
        $this->add_control(
            'show_postview',
            [
                'label' => esc_html__('Show Post Views', 'sportshub'),
                'type' =>Controls_Manager::SWITCHER,
                'label_on' => esc_html__('yes', 'sportshub'),
                'label_off' => esc_html__('no', 'sportshub'),
                'default' => 'yes',
            ]
        );
        $this->add_control(
            'show_contents',
            [
                'label' => esc_html__('Show Contents', 'sportshub'),
                'type' =>Controls_Manager::SWITCHER,
                'label_on' => esc_html__('yes', 'sportshub'),
                'label_off' => esc_html__('no', 'sportshub'),
                'default' => 'no',
            ]
        );
        $this->add_control(
          'count_words',
          [ 
            'condition' => [ 'show_contents' => 'yes' ],
            'label'         => esc_html__( 'Count Word', 'sportshub' ),
            'description'   => esc_html__( 'Select number of Words per Post (total words to show).', 'sportshub'),
            'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 1,
                        'max' => 80,
                    ],
                ],
                'default' => [
                    'size' => 14,
                ],   
          ]
        );
          

            
        $this->add_control(
            'post_sortby',
            [
                'label'     =>esc_html__( 'Post sort by', 'sportshub' ),
                'description' => esc_html__( 'Select sort order type for this block.', 'sportshub' ),
                'type'      =>Controls_Manager::SELECT,
                'default'   => 'latestpost',
                'options'   => [
                        'latestpost'      =>esc_html__( 'Latest posts', 'sportshub' ),
                        'popularposts'    =>esc_html__( 'Popular posts', 'sportshub' ),
                        'mostdiscussed'    =>esc_html__( 'Most discussed', 'sportshub' ),
                    ],
            ]
        );
        $this->add_control(
            'post_order',
            [
                'label'     =>esc_html__( 'Post order', 'sportshub' ),
                'type'      => Controls_Manager::CHOOSE,
                'default'   => 'DESC',
                'options'   => [
                        'DESC'      =>['title' => esc_html__( 'descending', 'sportshub' ),
                                       'icon' => 'fa fa-sort-amount-desc',],
                        'ASC'       =>['title' => esc_html__( 'ascending', 'sportshub' ),
                                       'icon' => 'fa fa-sort-amount-asc',],
                    ],
            ]
        );

        $this->add_control(
         'pagination_enable',
            [
               'label' => esc_html__('Pagination', 'sportshub'),
               'type' =>Controls_Manager::SWITCHER,
               'label_on' => esc_html__('yes', 'sportshub'),
               'label_off' => esc_html__('no', 'sportshub'),
               'default' => 'no',
               
            ]
      );
      
     
      $this->add_control(
         'offset_enable',
            [
               'label' => esc_html__('Post skip', 'sportshub'),
               'description'   => esc_html__( 'Select number of posts to pass over. Leave blank or set 0 if you want to show at the beginning.', 'sportshub'),
               'type' => Controls_Manager::SWITCHER,
               'label_on' => esc_html__('Yes', 'sportshub'),
               'label_off' => esc_html__('No', 'sportshub'),
               'default' => 'no',
               
            ]
      );
      
      $this->add_control(
         'offset_item_num',
         [
         'condition' => [ 'offset_enable' => 'yes' ],
         'label' => __('Skip Post count', 'sportshub'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'size' => 1,
                ],
         

         ]
      );

        $this->end_controls_section();

     //Title Style Section
    $this->start_controls_section(
      'section_tab_style', [
        'label'  => esc_html__( 'Post Custom Style', 'sportshub' ),
        'tab'     =>Controls_Manager::TAB_STYLE,
      ]
        );
     
     $this->add_control(
            'post_section_title',
            [
                'label'     =>esc_html__( 'Section Title Style', 'sportshub' ),
                'type'      => Controls_Manager::SELECT,
                'default'   => 'title_layout1',
                'options'   => [
                        'title_layout1'      =>esc_html__( 'Title Style 1', 'sportshub' ),
                        'title_layout2'    =>esc_html__( 'Title Style 2', 'sportshub' ),
                    ],
            ]
        );

      
      $this->add_control(
      'title_color', [

        'label'    => esc_html__( 'Title color', 'sportshub' ),
        'type'     => Controls_Manager::COLOR,
        'selectors'  => [

               '{{WRAPPER}} .blog-style-one .single-blog-style-one .text-box h3 a' => 'color: {{VALUE}};',
        ],
      ]
      );

      $this->add_control(
      'title_color_h', [

        'label'    => esc_html__( 'Title color hover', 'sportshub' ),
        'type'     => Controls_Manager::COLOR,
        'selectors'  => [

               '{{WRAPPER}} .blog-style-one .single-blog-style-one .text-box h3 a:hover' => 'color: {{VALUE}};',
        ],
      ]
      );
 
        $this->add_group_control(
      Group_Control_Typography::get_type(),
      [
        'name' => 'title_typography',
        'label' => esc_html__( 'Title Main Typography', 'sportshub' ),
        'scheme' =>Scheme_Typography::TYPOGRAPHY_1,
            
               'selector' => '{{WRAPPER}} .blog-style-one .single-blog-style-one .text-box h3 a',
      ]
        );      
         
        $this->end_controls_section();
    }

    protected function render( ) { 
        $settings = $this->get_settings();
        $post_title_html_tag = $settings['post_title_html_tag'];
        $show_thumbnail =$settings['show_thumbnail'];
        $show_cat = $settings['show_cat'];
        $show_meta = $settings['show_meta'];
        $show_author = $settings['show_author'];
        $show_date = $settings['show_date'];
        $show_postview = $settings['show_postview'];
        $show_contents =$settings['show_contents'];
        $section_title    = $settings['section_title'];
        $post_section_title    = $settings['post_section_title'];
        $post_grid_layout    = $settings['post_grid_layout'];
        $pagination_enable    = $settings['pagination_enable'];
        $thumbnail_size = $settings['thumbnail_size'];
        $post_grid_col    = $settings['post_grid_col'];
        $blog_text_align = $settings['blog_text_align'];
        $count_words = $settings['count_words']['size'];
        if ($show_meta=='no') {
            $show_author ="no";
            $show_date ="no";
            $show_postview ="no";
        }
            
        if($post_grid_col =='grid_col1'){
          $post_col = "col-md-12";
        }elseif($post_grid_col =='grid_col2'){
          $post_col = "col-md-6";
        }elseif($post_grid_col =='grid_col3'){
          $post_col = "col-md-4";
        }elseif($post_grid_col =='grid_col4'){
          $post_col = "col-md-3";
        }elseif($post_grid_col =='grid_col5'){
           $post_col = "col-md-2 col-sm-6";
        }   


        if($settings['pagination_enable']=='yes') {
        if(is_home() || is_front_page()) {
          $paged = get_query_var('page');
        } else {
          $paged = get_query_var('paged');
        }
        }        

        $arg = [
            'post_type'   =>  'post',
            'post_status' => 'publish',
            'order' => $settings['post_order'],
            'posts_per_page' => $settings['post_count']['size'],
            'category__in' => $settings['post_cats'],
            'ignore_sticky_posts' => 1,
        ];    

        if($settings['pagination_enable']=='yes') {
        $arg['paged'] = $paged;
        }


          if($settings['pagination_enable']!='yes') {
            $arg['offset'] = $settings['offset_item_num']['size'];          
          }
        
        switch($settings['post_sortby']){
         case 'mostdiscussed':
             $arg['orderby'] = 'comment_count';
         break;
         default:
             $arg['orderby'] = 'date';
         break;
     }     
          $query    = new \WP_Query($arg);
           if($section_title !=''){
           if($post_section_title == 'title_layout1'){
           ?> 
          <div class="themelazer_cat_sec_title">
                            <h3><?php echo esc_html($section_title); ?></h3>
                        </div>
          <?php }else{?>
                         <div class="themelazer_title_head">
                            <h3><?php echo esc_html($section_title); ?></h3>
                        </div>
          <?php }}?>

          

       
            <?php if ( $query->have_posts() ) : ?>
          <?php $i = 0; while ( $query->have_posts() ) : $query->the_post(); $i++; ?>
          <?php if($post_grid_layout == 'grid_layout1'){?>
           
                <!-- new area  -->

<div class="themelazer_article_list"><div class="post-outer"><?php if ( has_post_thumbnail()) {?><div class="post-inner"><div class="post-thumbnail sidebar">  <?php  if($show_thumbnail=='yes'){ if( has_post_thumbnail()) {the_post_thumbnail($thumbnail_size);}} ?><span class="themelazer_site_count"><?php echo esc_html($i); ?></span><a href="<?php the_permalink(); ?>"></a></div></div><?php }?><div class="post-inner"><div class="entry-header">
                         <?php if(get_theme_mod('disable_post_category') !=1){
               $categories = get_the_category(get_the_ID());          
               if ($categories) {
                if($show_cat=='yes'){
                 echo '<div class="themelazer_post_categories">';
                 foreach( $categories as $tag) {
                  echo '<a '.$tag->name.'" href="'.esc_url(get_category_link($tag->term_id)).'">'.$tag->name.'</a>';
                 }
                 echo "</div>";
                 }
                 }
                 }
               ?>
                        <h2 class="entry-title"> <a href="<?php the_permalink(); ?>">                      
                        <?php the_title()?></a></h2>
               <?php sportshub_post_meta_s(get_the_ID());?>
           </div></div></div></div>


<!-- old area -->


        <?php }elseif($post_grid_layout == 'grid_layout2'){?>
<div class="<?php echo esc_html($post_col); ?>">
<div class=" blog-style-one themelazer_card">
                <div class="single-blog-style-one">
         <div class="img-box themelazer_card <?php if ( has_post_thumbnail()){echo 'ghave_img';}else{echo 'gnone_img';}?>">
            <a href="<?php the_permalink(); ?>"><?php  if($show_thumbnail=='yes'){ if( has_post_thumbnail()) {the_post_thumbnail($thumbnail_size);}} ?></a>
         </div>                        
            
        
         <div class="text-box themelazer_card" <?php echo 'style="text-align:'.$blog_text_align.';'.'">'?>
          <?php if(get_theme_mod('disable_post_category') !=1){
               $categories = get_the_category(get_the_ID());          
               if ($categories) {
                 if($show_cat=='yes'){
                 echo '<div class="themelazer_post_categories">';
                 foreach( $categories as $tag) {
                  echo '<a '.$tag->name.'" href="'.esc_url(get_category_link($tag->term_id)).'">'.$tag->name.'</a>';
                 }
                 echo "</div>";
                 }
                 }
                 }
               ?>
            <?php echo '<'.$post_title_html_tag.'>'.'<a href="'.esc_url(get_the_permalink()).'" tabindex="-1">'.esc_attr(get_the_title()).'</a>'.'</'.$post_title_html_tag.'>' ?>
           <?php 
           if($show_meta =='yes'){
            echo'<div class="meta-info"> <ul>';
           if($show_author =='yes'){ echo '<li class="post-author">';
                 echo get_avatar(get_the_author_meta('ID'), 30);
                 echo the_author_posts_link();echo '</li>';
           } 
           if($show_date =='yes'){ echo '<li class="post-date">'.get_the_date().'</li>';}
            if($show_postview =='yes'){
                echo '<li class="post-view">';                
                echo sportshub_get_PostViews(get_the_ID()).' ';
                esc_html_e('Views', 'sportshub');                
                echo '</li>';
                }
                 echo'</ul></div>'; 
            }
           ?>



            <p><?php if($show_contents=='yes'){ echo wp_trim_words( get_the_content(), $count_words, '...' );}?> </p>
           
         </div>
      </div>
   </div>
          </div>   
              
        <?php }else{}?>

          
    <?php endwhile;
echo "</div>";    
if($settings['pagination_enable']=='yes') {
echo '<div class="themelazer-pagination">
      <div class="themelazer-pagination-wrapper">
        '. sportshub_pagination_num( array( 'paged' => $paged , 'total' => $query->max_num_pages ) ).'</div></div>';
    wp_reset_postdata();
}

?>
              
        <?php endif; ?>

      <?php  
    }
    protected function _content_template() { }

    public function post_category() {

      $terms = get_terms( array(
            'taxonomy'    => 'category',
            'hide_empty'  => false,
            'posts_per_page' => -1, 
            'suppress_filters' => false,
      ) );

      $cat_list = [];
      foreach($terms as $post) {
      $cat_list[$post->term_id]  = [$post->name];
      }
      return $cat_list;
   }
}